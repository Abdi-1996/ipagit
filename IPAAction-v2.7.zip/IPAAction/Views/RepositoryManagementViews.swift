import SwiftUI

struct CreateRepositoryView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel

    @State private var name = ""
    @State private var description = ""
    @State private var isPrivate = true
    @State private var isWorking = false

    var body: some View {
        NavigationStack {
            Form {
                Section("Repository") {
                    TextField("Repository name", text: $name)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                    TextField("Description (optional)", text: $description, axis: .vertical)
                    Toggle("Private repository", isOn: $isPrivate)
                }

                Section {
                    Text("Creating, renaming or deleting repositories requires Administration — Read & Write on the GitHub token.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("New Repository")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        Task { await create() }
                    } label: {
                        if isWorking { ProgressView() }
                        else { Text("Create").fontWeight(.semibold) }
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || isWorking)
                }
            }
        }
    }

    private func create() async {
        isWorking = true
        defer { isWorking = false }
        do {
            _ = try await model.createRepository(name: name, description: description, isPrivate: isPrivate)
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct RenameRepositoryView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    let repository: GitHubRepository

    @State private var newName: String
    @State private var isWorking = false

    init(repository: GitHubRepository) {
        self.repository = repository
        _newName = State(initialValue: repository.name)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Rename repository") {
                    TextField("New name", text: $newName)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }
                Section {
                    Text("GitHub keeps redirects for many old repository URLs after a rename, but update your own links and workflows if they contain the old name.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Rename")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button {
                        Task { await rename() }
                    } label: {
                        if isWorking { ProgressView() }
                        else { Text("Save").fontWeight(.semibold) }
                    }
                    .disabled(newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || newName == repository.name || isWorking)
                }
            }
        }
    }

    private func rename() async {
        isWorking = true
        defer { isWorking = false }
        do {
            _ = try await model.renameRepository(repository, newName: newName)
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

struct RepositorySettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    let repository: GitHubRepository

    @State private var showRename = false
    @State private var showDelete = false
    @State private var isDeleting = false

    var body: some View {
        Form {
            Section("Repository") {
                LabeledContent("Name", value: repository.name)
                LabeledContent("Owner", value: repository.owner.login)
                LabeledContent("Visibility", value: repository.private ? "Private" : "Public")
                LabeledContent("Default branch", value: repository.default_branch)
            }

            Section("Manage") {
                Button {
                    showRename = true
                } label: {
                    Label("Rename repository", systemImage: "pencil")
                }

                Button(role: .destructive) {
                    showDelete = true
                } label: {
                    HStack {
                        Label("Delete repository", systemImage: "trash")
                        Spacer()
                        if isDeleting { ProgressView() }
                    }
                }
                .disabled(isDeleting)
            }
        }
        .navigationTitle("Repository Settings")
        .sheet(isPresented: $showRename) {
            RenameRepositoryView(repository: repository)
        }
        .alert("Delete \(repository.name)?", isPresented: $showDelete) {
            Button("Cancel", role: .cancel) {}
            Button("Delete permanently", role: .destructive) {
                Task { await deleteRepository() }
            }
        } message: {
            Text("This permanently deletes the repository and its files from GitHub. This cannot be undone from IPA Action.")
        }
    }

    private func deleteRepository() async {
        isDeleting = true
        defer { isDeleting = false }
        do {
            try await model.deleteRepository(repository)
            dismiss()
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}
