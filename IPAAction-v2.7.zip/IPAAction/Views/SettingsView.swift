import SwiftUI

struct SettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel
    @State private var revealToken = false
    @State private var revealAPIKey = false

    var body: some View {
        NavigationStack {
            Form {
                Section("GitHub") {
                    if revealToken {
                        TextField("Fine-grained token", text: $model.token).textInputAutocapitalization(.never).autocorrectionDisabled()
                    } else {
                        SecureField("Fine-grained token", text: $model.token).textInputAutocapitalization(.never).autocorrectionDisabled()
                    }
                    Toggle("Show token", isOn: $revealToken)
                    Text("Recommended for full management: Actions — Read & Write; Contents — Read & Write; Workflows — Read & Write; Administration — Read & Write. Administration is required to create, rename or delete repositories. If you want newly created repositories to stay accessible without editing the token each time, use repository access: All repositories.")
                        .font(.caption).foregroundStyle(.secondary)
                }

                Section("Sideloader") {
                    TextField("https://your-pc.tailnet.ts.net", text: $model.sideloaderURL)
                        .textInputAutocapitalization(.never).autocorrectionDisabled().keyboardType(.URL)
                    if revealAPIKey { TextField("API key (optional)", text: $model.sideloaderAPIKey) }
                    else { SecureField("API key (optional)", text: $model.sideloaderAPIKey) }
                    Toggle("Show API key", isOn: $revealAPIKey)
                    Text("Install uses POST /api/install with the IPA as multipart field named “ipa”. This PC adapter is optional; building/downloading with GitHub Actions does not need the PC.")
                        .font(.caption).foregroundStyle(.secondary)
                }
            }
            .navigationTitle("Settings")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        Task { await model.saveSettings(); dismiss() }
                    }.fontWeight(.semibold)
                }
            }
        }
    }
}
