import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct ProjectImportView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel

    @State private var selectedRepositoryID: Int?
    @State private var branches: [GitHubBranch] = []
    @State private var selectedBranch = ""
    @State private var createNewBranch = false
    @State private var newBranch = "build"

    @State private var projectURL: URL?
    @State private var projectFileName = ""
    @State private var projectFileSize: Int64 = 0
    @State private var showDocumentPicker = false
    @State private var isImportingFile = false

    @State private var isProcessing = false
    @State private var stage = ""
    @State private var successMessage: String?
    @State private var localError: String?

    private let workflowPath = ".github/workflows/ipaaction-auto-build.yml"
    private let remoteArchivePath = "IPAActionProject.zip"

    private var selectedRepository: GitHubRepository? {
        model.repositories.first(where: { $0.id == selectedRepositoryID })
    }

    private var targetBranch: String {
        createNewBranch ? WorkflowTemplates.sanitizedBranch(newBranch) : selectedBranch
    }

    private var canStart: Bool {
        projectURL != nil && selectedRepository != nil && !targetBranch.isEmpty && !isProcessing && !isImportingFile
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("1. Project ZIP") {
                    Button {
                        showDocumentPicker = true
                    } label: {
                        fileCard
                    }
                    .buttonStyle(.plain)
                    .disabled(isImportingFile || isProcessing)

                    if projectURL != nil {
                        HStack {
                            Label("ZIP selected", systemImage: "checkmark.circle.fill")
                                .foregroundStyle(.green)
                            Spacer()
                            Button("Choose another") {
                                showDocumentPicker = true
                            }
                            .disabled(isImportingFile || isProcessing)
                        }

                        LabeledContent("Upload as") {
                            Text(remoteArchivePath)
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                        }
                    }
                }

                Section("2. GitHub destination") {
                    Picker("Repository", selection: $selectedRepositoryID) {
                        Text("Select repository").tag(Int?.none)
                        ForEach(model.repositories) { repo in
                            Text(repo.full_name).tag(Optional(repo.id))
                        }
                    }

                    if selectedRepository != nil {
                        Toggle("Create new branch", isOn: $createNewBranch)

                        if createNewBranch {
                            TextField("New branch", text: $newBranch)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled()

                            Picker("Create from", selection: $selectedBranch) {
                                ForEach(branches) { branch in
                                    Text(branch.name).tag(branch.name)
                                }
                            }
                        } else {
                            Picker("Branch", selection: $selectedBranch) {
                                ForEach(branches) { branch in
                                    Text(branch.name).tag(branch.name)
                                }
                            }
                        }
                    }
                }

                Section("3. Auto workflow") {
                    Label("Workflow is created automatically", systemImage: "wand.and.stars")
                        .foregroundStyle(.primary)
                    Text("The selected ZIP is always uploaded as IPAActionProject.zip, so the workflow and file name cannot get out of sync.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Status") {
                    if isImportingFile {
                        HStack(spacing: 10) {
                            ProgressView()
                            Text(stage.isEmpty ? "Importing ZIP…" : stage)
                        }
                    } else if stage.isEmpty {
                        Text("Choose a ZIP. When import succeeds, a green checkmark and file size appear here.")
                            .foregroundStyle(.secondary)
                    } else {
                        HStack(spacing: 10) {
                            if isProcessing { ProgressView() }
                            Text(stage)
                        }
                    }
                }
            }
            .navigationTitle("New IPA Build")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .safeAreaInset(edge: .bottom) {
                buildBar
            }
            .sheet(isPresented: $showDocumentPicker) {
                ZIPDocumentPicker(
                    onPick: { url in
                        showDocumentPicker = false
                        selectedFromPicker(url)
                    },
                    onCancel: {
                        showDocumentPicker = false
                    }
                )
                .ignoresSafeArea()
            }
            .task(id: selectedRepositoryID) {
                await loadDestinationData()
            }
            .alert("Import error", isPresented: Binding(
                get: { localError != nil },
                set: { if !$0 { localError = nil } }
            )) {
                Button("OK", role: .cancel) { localError = nil }
            } message: {
                Text(localError ?? "Unknown error")
            }
            .alert("Build started", isPresented: Binding(
                get: { successMessage != nil },
                set: { if !$0 { successMessage = nil } }
            )) {
                Button("Done") { dismiss() }
            } message: {
                Text(successMessage ?? "Build started.")
            }
        }
    }

    private var fileCard: some View {
        HStack(spacing: 12) {
            ZStack {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .fill(projectURL == nil ? Color.accentColor.opacity(0.12) : Color.green.opacity(0.14))
                    .frame(width: 46, height: 46)

                if isImportingFile {
                    ProgressView()
                } else {
                    Image(systemName: projectURL == nil ? "doc.zipper" : "checkmark.circle.fill")
                        .font(.title3)
                        .foregroundStyle(projectURL == nil ? Color.accentColor : Color.green)
                }
            }

            VStack(alignment: .leading, spacing: 4) {
                Text(projectURL == nil ? "Choose ZIP from Files" : projectFileName)
                    .fontWeight(.semibold)
                    .foregroundStyle(.primary)
                    .lineLimit(1)

                if projectURL != nil {
                    Text("Ready • \(ByteCountFormatter.string(fromByteCount: projectFileSize, countStyle: .file))")
                        .font(.caption)
                        .foregroundStyle(.green)
                } else {
                    Text("Files, iCloud Drive and third-party file providers")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Spacer()
            Image(systemName: "folder")
                .foregroundStyle(.secondary)
        }
        .contentShape(Rectangle())
    }

    private var buildBar: some View {
        VStack(spacing: 6) {
            Button {
                Task { await startProcess() }
            } label: {
                HStack {
                    if isProcessing {
                        ProgressView().tint(.white)
                    } else {
                        Image(systemName: "hammer.fill")
                    }
                    Text(isProcessing ? "WORKING…" : "BUILD IPA")
                        .fontWeight(.bold)
                    Spacer()
                    if !isProcessing { Image(systemName: "arrow.right.circle.fill") }
                }
                .padding(.horizontal, 18)
                .frame(height: 54)
                .foregroundStyle(.white)
                .background(canStart ? Color.accentColor : Color.secondary, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(!canStart)

            if !canStart && !isProcessing {
                Text(missingRequirementText)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(.horizontal)
        .padding(.top, 8)
        .padding(.bottom, 4)
        .background(.ultraThinMaterial)
    }

    private var missingRequirementText: String {
        if isImportingFile { return "Importing selected ZIP…" }
        if projectURL == nil { return "Choose a ZIP file" }
        if selectedRepository == nil { return "Choose a repository" }
        if targetBranch.isEmpty { return "Choose a branch" }
        return "Ready"
    }

    @MainActor
    private func selectedFromPicker(_ sourceURL: URL) {
        // Visible feedback immediately after the picker returns.
        projectURL = nil
        projectFileName = sourceURL.lastPathComponent
        projectFileSize = 0
        isImportingFile = true
        stage = "Selected \(sourceURL.lastPathComponent). Copying into IPA Action…"
        localError = nil

        Task {
            do {
                let imported = try await copySelectedZIP(sourceURL)
                await MainActor.run {
                    projectURL = imported.url
                    projectFileName = imported.originalName
                    projectFileSize = imported.size
                    isImportingFile = false
                    stage = "✓ ZIP ready: \(imported.originalName)"
                }
            } catch {
                await MainActor.run {
                    projectURL = nil
                    projectFileSize = 0
                    isImportingFile = false
                    stage = "Import failed"
                    localError = error.localizedDescription
                }
            }
        }
    }

    private func copySelectedZIP(_ sourceURL: URL) async throws -> ImportedProjectFile {
        try await Task.detached(priority: .userInitiated) {
            let name = sourceURL.lastPathComponent
            guard name.lowercased().hasSuffix(".zip") else {
                throw ProjectImportError.notZip
            }

            let fm = FileManager.default
            let support = try fm.url(
                for: .applicationSupportDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
            )
            let imports = support.appendingPathComponent("IPAActionImports", isDirectory: true)
            try fm.createDirectory(at: imports, withIntermediateDirectories: true)

            let localURL = imports.appendingPathComponent("IPAActionProject.zip")
            try? fm.removeItem(at: localURL)

            let scoped = sourceURL.startAccessingSecurityScopedResource()
            defer {
                if scoped { sourceURL.stopAccessingSecurityScopedResource() }
            }

            // The UIKit picker is created with asCopy=true. Most providers already return
            // a sandbox-readable copy; FileCoordinator handles providers that still vend a coordinated URL.
            let coordinator = NSFileCoordinator(filePresenter: nil)
            var coordinatorError: NSError?
            var operationError: Error?

            coordinator.coordinate(readingItemAt: sourceURL, options: [], error: &coordinatorError) { readableURL in
                do {
                    try fm.copyItem(at: readableURL, to: localURL)
                } catch {
                    operationError = error
                }
            }

            if let coordinatorError { throw coordinatorError }
            if let operationError { throw operationError }

            let attrs = try fm.attributesOfItem(atPath: localURL.path)
            let size = (attrs[.size] as? NSNumber)?.int64Value ?? 0
            guard size > 0 else { throw ProjectImportError.emptyFile }
            guard size <= 75 * 1024 * 1024 else { throw GitHubAPIError.fileTooLarge(size) }

            let handle = try FileHandle(forReadingFrom: localURL)
            defer { try? handle.close() }
            let signature = try handle.read(upToCount: 4) ?? Data()
            guard signature.count >= 2,
                  signature[signature.startIndex] == 0x50,
                  signature[signature.index(after: signature.startIndex)] == 0x4B else {
                throw ProjectImportError.invalidZip
            }

            return ImportedProjectFile(url: localURL, originalName: name, size: size)
        }.value
    }

    private func loadDestinationData() async {
        guard let repo = selectedRepository else {
            branches = []
            selectedBranch = ""
            return
        }

        do {
            stage = projectURL == nil ? "" : stage
            let loadedBranches = try await model.githubAPI().branches(owner: repo.owner.login, repo: repo.name)
            branches = loadedBranches
            selectedBranch = loadedBranches.first(where: { $0.name == repo.default_branch })?.name
                ?? loadedBranches.first?.name
                ?? repo.default_branch
        } catch {
            localError = error.localizedDescription
        }
    }

    private func startProcess() async {
        guard canStart,
              let repo = selectedRepository,
              let projectURL else { return }

        let branch = targetBranch
        isProcessing = true
        localError = nil
        defer { isProcessing = false }

        do {
            if createNewBranch {
                stage = "Creating branch \(branch)…"
                try await model.githubAPI().ensureBranch(
                    owner: repo.owner.login,
                    repo: repo.name,
                    branch: branch,
                    baseBranch: selectedBranch
                )
            }

            stage = "Creating/updating workflow…"
            let yaml = WorkflowTemplates.universalIPA(
                archivePath: remoteArchivePath,
                branch: branch,
                workflowPath: workflowPath
            )
            guard let workflowData = yaml.data(using: .utf8) else {
                throw GitHubAPIError.invalidResponse
            }

            _ = try await model.githubAPI().uploadFile(
                owner: repo.owner.login,
                repo: repo.name,
                path: workflowPath,
                data: workflowData,
                branch: branch,
                message: "Create IPA Action auto-build workflow"
            )

            stage = "Uploading ZIP to GitHub…"
            let projectData = try Data(contentsOf: projectURL, options: .mappedIfSafe)
            _ = try await model.githubAPI().uploadFile(
                owner: repo.owner.login,
                repo: repo.name,
                path: remoteArchivePath,
                data: projectData,
                branch: branch,
                message: "Import iOS project and start IPA build"
            )

            stage = "✓ Uploaded. GitHub Actions started."
            successMessage = "The ZIP was uploaded as \(remoteArchivePath). The push starts the auto-build workflow on \(repo.full_name) / \(branch)."
        } catch {
            stage = "Build start failed"
            localError = error.localizedDescription
        }
    }
}

private struct ImportedProjectFile: Sendable {
    let url: URL
    let originalName: String
    let size: Int64
}

enum ProjectImportError: LocalizedError {
    case notZip
    case emptyFile
    case invalidZip

    var errorDescription: String? {
        switch self {
        case .notZip:
            return "Choose a ZIP file (.zip)."
        case .emptyFile:
            return "The selected ZIP is empty."
        case .invalidZip:
            return "The selected file is not a valid ZIP archive."
        }
    }
}

private struct ZIPDocumentPicker: UIViewControllerRepresentable {
    let onPick: (URL) -> Void
    let onCancel: () -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onPick: onPick, onCancel: onCancel)
    }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let zip = UTType(filenameExtension: "zip") ?? .archive
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: [zip, .archive, .data],
            asCopy: true
        )
        picker.delegate = context.coordinator
        picker.allowsMultipleSelection = false
        picker.shouldShowFileExtensions = true
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let onPick: (URL) -> Void
        let onCancel: () -> Void

        init(onPick: @escaping (URL) -> Void, onCancel: @escaping () -> Void) {
            self.onPick = onPick
            self.onCancel = onCancel
        }

        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard let url = urls.first else {
                onCancel()
                return
            }
            onPick(url)
        }

        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            onCancel()
        }
    }
}
