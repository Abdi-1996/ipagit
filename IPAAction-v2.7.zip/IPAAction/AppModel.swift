import Foundation
import SwiftUI

@MainActor
final class AppModel: ObservableObject {
    @Published var token: String = ""
    @Published var repositories: [GitHubRepository] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    @Published var sideloaderURL: String = UserDefaults.standard.string(forKey: "sideloaderURL") ?? "https://home-pc-1.tail2d1d77.ts.net"
    @Published var sideloaderAPIKey: String = KeychainStore.get(account: "sideloader-api-key") ?? ""

    private var api = GitHubAPI(token: "")

    func bootstrap() async {
        token = KeychainStore.get(account: "github-token") ?? ""
        await api.setToken(token)
        if !token.isEmpty { await loadRepositories() }
    }

    func saveSettings() async {
        do {
            if token.isEmpty { KeychainStore.delete(account: "github-token") }
            else { try KeychainStore.set(token, account: "github-token") }
            if sideloaderAPIKey.isEmpty { KeychainStore.delete(account: "sideloader-api-key") }
            else { try KeychainStore.set(sideloaderAPIKey, account: "sideloader-api-key") }
            UserDefaults.standard.set(sideloaderURL, forKey: "sideloaderURL")
            await api.setToken(token)
            if !token.isEmpty { await loadRepositories() }
        } catch { errorMessage = error.localizedDescription }
    }

    func loadRepositories() async {
        guard !token.isEmpty else { repositories = []; return }
        isLoading = true
        defer { isLoading = false }
        do {
            await api.setToken(token)
            repositories = try await api.repositories()
        } catch { errorMessage = error.localizedDescription }
    }

    func createRepository(name: String, description: String, isPrivate: Bool) async throws -> GitHubRepository {
        let repo = try await api.createRepository(name: name, description: description, isPrivate: isPrivate)
        repositories.removeAll { $0.id == repo.id }
        repositories.insert(repo, at: 0)
        return repo
    }

    func renameRepository(_ repository: GitHubRepository, newName: String) async throws -> GitHubRepository {
        let updated = try await api.renameRepository(owner: repository.owner.login, repo: repository.name, newName: newName)
        if let index = repositories.firstIndex(where: { $0.id == repository.id }) {
            repositories[index] = updated
        }
        return updated
    }

    func deleteRepository(_ repository: GitHubRepository) async throws {
        try await api.deleteRepository(owner: repository.owner.login, repo: repository.name)
        repositories.removeAll { $0.id == repository.id }
    }

    func githubAPI() -> GitHubAPI { api }
}
