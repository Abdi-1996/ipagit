# IPA Action v2.5 — быстрый старт

После установки открой Settings и вставь GitHub fine-grained token.

Для полного управления включи:
- Actions — Read and write
- Contents — Read and write
- Workflows — Read and write
- Administration — Read and write

На главном экране `+`:
- New Repository — создать репозиторий
- Import Project ZIP — загрузить ZIP проекта и запустить сборку IPA
- Import Workflow — импортировать workflow

Открой репозиторий → Files:
- `+` → New Text File
- `+` → New Folder
- `+` → Import File
- свайп по файлу/папке → Rename/Move или Delete
- открой текстовый файл → Edit → Save
