# IPA Action v2.5

IPA Action is an iPhone GitHub Actions client for building iOS IPA files and managing GitHub repositories/files.

## v2.5

- Create repositories
- Rename repositories
- Delete repositories with confirmation
- Browse repository files by branch
- Create text files
- Create folders (`.gitkeep` is used because Git does not store empty folders)
- Import any file from iPhone Files/iCloud into a repository
- Edit UTF-8 text files directly in the app
- Rename or move files and folders
- Delete files or whole folders
- Share/save repository files to iPhone
- Existing project ZIP import and GitHub Actions IPA build flow

## Recommended fine-grained token permissions

For full management:
- Actions: Read and write
- Contents: Read and write
- Workflows: Read and write
- Administration: Read and write

If you create repositories from the app and want future repositories to be accessible automatically, use `All repositories` for repository access.
