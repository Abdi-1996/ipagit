import SwiftUI
import UniformTypeIdentifiers

struct WorkflowImportView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject private var model: AppModel

    @State private var selectedRepositoryID: Int?
    @State private var branches: [GitHubBranch] = []
    @State private var selectedBranch = ""
    @State private var workflowURL: URL?
    @State private var workflowName = ""
    @State private var remotePath = ".github/workflows/custom-build.yml"
    @State private var showImporter = false
    @State private var isUploading = false
    @State private var success = false

    private var selectedRepository: GitHubRepository? {
        model.repositories.first(where: { $0.id == selectedRepositoryID })
    }

    private var canUpload: Bool {
        workflowURL != nil && selectedRepository != nil && !selectedBranch.isEmpty && !isUploading
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("Workflow file") {
                    Button {
                        showImporter = true
                    } label: {
                        HStack {
                            Image(systemName: workflowURL == nil ? "doc.badge.gearshape" : "checkmark.circle.fill")
                                .foregroundStyle(workflowURL == nil ? Color.accentColor : Color.green)
                            Text(workflowURL == nil ? "Choose .yml / .yaml" : workflowName)
                                .fontWeight(.semibold)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundStyle(.tertiary)
                        }
                    }

                    TextField("Remote path", text: $remotePath)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                Section("GitHub destination") {
                    Picker("Repository", selection: $selectedRepositoryID) {
                        Text("Select repository").tag(Int?.none)
                        ForEach(model.repositories) { repo in
                            Text(repo.full_name).tag(Optional(repo.id))
                        }
                    }

                    if selectedRepository != nil {
                        Picker("Branch", selection: $selectedBranch) {
                            ForEach(branches) { branch in
                                Text(branch.name).tag(branch.name)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Import Workflow")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .safeAreaInset(edge: .bottom) {
                Button {
                    Task { await upload() }
                } label: {
                    HStack {
                        if isUploading { ProgressView().tint(.white) }
                        else { Image(systemName: "icloud.and.arrow.up.fill") }
                        Text(isUploading ? "UPLOADING…" : "UPLOAD WORKFLOW")
                            .fontWeight(.bold)
                        Spacer()
                    }
                    .padding(.horizontal, 18)
                    .frame(height: 54)
                    .foregroundStyle(.white)
                    .background(canUpload ? Color.accentColor : Color.secondary, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
                }
                .buttonStyle(.plain)
                .disabled(!canUpload)
                .padding(.horizontal)
                .padding(.vertical, 10)
                .background(.ultraThinMaterial)
            }
            .fileImporter(isPresented: $showImporter, allowedContentTypes: [.item], allowsMultipleSelection: false) { result in
                handleWorkflowSelection(result)
            }
            .task(id: selectedRepositoryID) {
                await loadBranches()
            }
            .alert("Workflow uploaded", isPresented: $success) {
                Button("Done") { dismiss() }
            } message: {
                Text("The workflow is now available in GitHub Actions for this repository/branch.")
            }
        }
    }

    private func handleWorkflowSelection(_ result: Result<[URL], Error>) {
        do {
            guard let sourceURL = try result.get().first else { return }
            let ext = sourceURL.pathExtension.lowercased()
            guard ext == "yml" || ext == "yaml" else { throw WorkflowImportError.invalidExtension }

            let scoped = sourceURL.startAccessingSecurityScopedResource()
            defer { if scoped { sourceURL.stopAccessingSecurityScopedResource() } }

            let fm = FileManager.default
            let imports = fm.temporaryDirectory.appendingPathComponent("IPAActionWorkflowImports", isDirectory: true)
            try fm.createDirectory(at: imports, withIntermediateDirectories: true)

            let safeName = WorkflowTemplates.sanitizedFileName(sourceURL.lastPathComponent, fallback: "custom-build.yml")
            let localURL = imports.appendingPathComponent("\(UUID().uuidString)-\(safeName)")
            try fm.copyItem(at: sourceURL, to: localURL)

            workflowURL = localURL
            workflowName = sourceURL.lastPathComponent
            remotePath = ".github/workflows/\(safeName)"
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func loadBranches() async {
        guard let repo = selectedRepository else {
            branches = []
            selectedBranch = ""
            return
        }

        do {
            branches = try await model.githubAPI().branches(owner: repo.owner.login, repo: repo.name)
            selectedBranch = branches.first(where: { $0.name == repo.default_branch })?.name
                ?? branches.first?.name
                ?? repo.default_branch
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }

    private func upload() async {
        guard canUpload, let repo = selectedRepository, let workflowURL else { return }
        isUploading = true
        defer { isUploading = false }

        do {
            let data = try Data(contentsOf: workflowURL)
            _ = try await model.githubAPI().uploadFile(
                owner: repo.owner.login,
                repo: repo.name,
                path: remotePath,
                data: data,
                branch: selectedBranch,
                message: "Import workflow from IPA Action"
            )
            success = true
        } catch {
            model.errorMessage = error.localizedDescription
        }
    }
}

enum WorkflowImportError: LocalizedError {
    case invalidExtension

    var errorDescription: String? {
        "Choose a .yml or .yaml workflow file."
    }
}
