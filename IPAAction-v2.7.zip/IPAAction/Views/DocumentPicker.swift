import SwiftUI
import UniformTypeIdentifiers
import UIKit

struct ImportedLocalFile: Identifiable, Hashable, Sendable {
    let id: UUID
    let url: URL
    let originalName: String
    let size: Int64

    init(id: UUID = UUID(), url: URL, originalName: String, size: Int64) {
        self.id = id
        self.url = url
        self.originalName = originalName
        self.size = size
    }
}

enum DocumentImportError: LocalizedError {
    case noFiles
    case copyFailed(String)
    case emptyFile(String)

    var errorDescription: String? {
        switch self {
        case .noFiles:
            return "No files were selected."
        case let .copyFailed(message):
            return "Could not copy the selected file into IPA Action: \(message)"
        case let .emptyFile(name):
            return "The selected file “\(name)” is empty."
        }
    }
}

/// System Files picker used by repository import.
/// Selected provider URLs are immediately copied into Application Support so
/// iCloud / Files / third-party provider access cannot disappear after dismissal.
struct AnyDocumentPicker: UIViewControllerRepresentable {
    let allowsMultipleSelection: Bool
    let onPick: ([ImportedLocalFile]) -> Void
    let onError: (Error) -> Void
    let onCancel: () -> Void

    init(
        allowsMultipleSelection: Bool = true,
        onPick: @escaping ([ImportedLocalFile]) -> Void,
        onError: @escaping (Error) -> Void,
        onCancel: @escaping () -> Void
    ) {
        self.allowsMultipleSelection = allowsMultipleSelection
        self.onPick = onPick
        self.onError = onError
        self.onCancel = onCancel
    }

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
        let picker = UIDocumentPickerViewController(
            forOpeningContentTypes: [.item, .data, .content],
            asCopy: true
        )
        picker.allowsMultipleSelection = allowsMultipleSelection
        picker.shouldShowFileExtensions = true
        picker.delegate = context.coordinator
        return picker
    }

    func updateUIViewController(_ uiViewController: UIDocumentPickerViewController, context: Context) {}

    final class Coordinator: NSObject, UIDocumentPickerDelegate {
        let parent: AnyDocumentPicker
        init(parent: AnyDocumentPicker) { self.parent = parent }

        @MainActor
        func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
            guard !urls.isEmpty else {
                parent.onError(DocumentImportError.noFiles)
                return
            }

            Task {
                do {
                    let files = try await Self.persistSelectedFiles(urls)
                    await MainActor.run { self.parent.onPick(files) }
                } catch {
                    await MainActor.run { self.parent.onError(error) }
                }
            }
        }

        @MainActor
        func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
            parent.onCancel()
        }

        private static func persistSelectedFiles(_ urls: [URL]) async throws -> [ImportedLocalFile] {
            try await Task.detached(priority: .userInitiated) {
                let fm = FileManager.default
                let support = try fm.url(
                    for: .applicationSupportDirectory,
                    in: .userDomainMask,
                    appropriateFor: nil,
                    create: true
                )
                let importRoot = support
                    .appendingPathComponent("RepositoryImports", isDirectory: true)
                    .appendingPathComponent(UUID().uuidString, isDirectory: true)
                try fm.createDirectory(at: importRoot, withIntermediateDirectories: true)

                var result: [ImportedLocalFile] = []
                var usedNames = Set<String>()

                for sourceURL in urls {
                    let originalName = sourceURL.lastPathComponent.isEmpty ? "ImportedFile" : sourceURL.lastPathComponent
                    let localName = uniqueName(originalName, used: &usedNames)
                    let destination = importRoot.appendingPathComponent(localName)

                    let scoped = sourceURL.startAccessingSecurityScopedResource()
                    defer {
                        if scoped { sourceURL.stopAccessingSecurityScopedResource() }
                    }

                    let coordinator = NSFileCoordinator(filePresenter: nil)
                    var coordinatorError: NSError?
                    var readError: Error?
                    var copiedSize: Int64 = 0

                    coordinator.coordinate(readingItemAt: sourceURL, options: [], error: &coordinatorError) { readableURL in
                        do {
                            // Reading to Data forces cloud/provider-backed files to be fully materialized
                            // while the security-scoped URL is valid.
                            let data = try Data(contentsOf: readableURL, options: .mappedIfSafe)
                            guard !data.isEmpty else {
                                throw DocumentImportError.emptyFile(originalName)
                            }
                            try data.write(to: destination, options: .atomic)
                            copiedSize = Int64(data.count)
                        } catch {
                            readError = error
                        }
                    }

                    if let coordinatorError { throw coordinatorError }
                    if let readError { throw DocumentImportError.copyFailed("\(originalName): \(readError.localizedDescription)") }
                    guard fm.fileExists(atPath: destination.path), copiedSize > 0 else {
                        throw DocumentImportError.copyFailed("\(originalName): local copy was not created")
                    }

                    result.append(ImportedLocalFile(
                        url: destination,
                        originalName: originalName,
                        size: copiedSize
                    ))
                }

                return result
            }.value
        }

        private static func uniqueName(_ name: String, used: inout Set<String>) -> String {
            if !used.contains(name) {
                used.insert(name)
                return name
            }
            let ns = name as NSString
            let base = ns.deletingPathExtension
            let ext = ns.pathExtension
            var index = 2
            while true {
                let candidate = ext.isEmpty ? "\(base)-\(index)" : "\(base)-\(index).\(ext)"
                if !used.contains(candidate) {
                    used.insert(candidate)
                    return candidate
                }
                index += 1
            }
        }
    }
}
