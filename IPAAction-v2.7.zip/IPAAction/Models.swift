import Foundation

struct GitHubRepository: Codable, Identifiable, Hashable {
    struct Owner: Codable, Hashable { let login: String }
    let id: Int
    let name: String
    let full_name: String
    let `private`: Bool
    let default_branch: String
    let owner: Owner
}

struct GitHubWorkflow: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let path: String
    let state: String
}

struct WorkflowListResponse: Codable { let total_count: Int; let workflows: [GitHubWorkflow] }

struct GitHubBranch: Codable, Identifiable, Hashable {
    var id: String { name }
    let name: String
}

struct GitHubRun: Codable, Identifiable, Hashable {
    let id: Int
    let name: String?
    let event: String
    let status: String
    let conclusion: String?
    let html_url: String
    let run_number: Int
    let created_at: String
    let updated_at: String
    let head_branch: String?
}

struct RunListResponse: Codable { let total_count: Int; let workflow_runs: [GitHubRun] }

struct GitHubArtifact: Codable, Identifiable, Hashable {
    let id: Int
    let name: String
    let size_in_bytes: Int
    let expired: Bool
    let archive_download_url: String
}

struct ArtifactListResponse: Codable { let total_count: Int; let artifacts: [GitHubArtifact] }

struct GitHubContentMetadata: Codable {
    let sha: String
    let path: String?
    let name: String?
}

struct GitHubReference: Codable {
    struct Object: Codable { let sha: String }
    let ref: String
    let object: Object
}

struct UploadedRepositoryFile: Hashable {
    let path: String
    let branch: String
}

struct GitHubContentItem: Codable, Identifiable, Hashable {
    var id: String { path }
    let name: String
    let path: String
    let sha: String
    let type: String
    let size: Int?
    let download_url: String?

    var isDirectory: Bool { type == "dir" }
}

struct GitHubFileContent: Codable {
    let name: String
    let path: String
    let sha: String
    let type: String
    let size: Int?
    let content: String?
    let encoding: String?
    let download_url: String?
}

enum BuildStateLabel {
    static func text(status: String, conclusion: String?) -> String {
        if status != "completed" { return status.replacingOccurrences(of: "_", with: " ").capitalized }
        return (conclusion ?? "completed").replacingOccurrences(of: "_", with: " ").capitalized
    }
}
